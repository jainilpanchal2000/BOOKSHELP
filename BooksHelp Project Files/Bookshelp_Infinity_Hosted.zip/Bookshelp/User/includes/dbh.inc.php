<?php


define('DB_SERVER', 'sql211.epizy.com');
define('DB_USER', 'epiz_25362016');
define('DB_PASS', 'FDkDG1Skxg4nNOF');
define('DB_NAME', 'epiz_25362016_Bookshelp');

$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
if(!$con){
	die("Connection Failed".mysqli_connect_error());
}
?>