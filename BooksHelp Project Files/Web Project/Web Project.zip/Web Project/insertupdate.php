<?php
    session_start();
    $id = $_SESSION['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $branch = $_POST['branch'];
    $year = $_POST['year'];
    $clg = $_POST['college'];
    $add = $_POST['address'];
    $photo = $_FILES['pic']['name'];
    $filetmp = $_FILES['pic']['tmp_name'];
    $filetype = $_FILES['pic']['type'];
    $path = "upload/".$photo;
    

    if(!empty($name))
    {
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "bookshelp";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        
        if(mysqli_connect_error()){
            die('Connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
        } else {
            
            move_uploaded_file($filetmp,$path);

            $INSERT = "UPDATE profile SET branch='".mysqli_real_escape_string($conn,$branch)."', year='".mysqli_real_escape_string($conn,$year)."', college='".mysqli_real_escape_string($conn,$clg)."', address='".mysqli_real_escape_string($conn,$add)."',  photo='".mysqli_real_escape_string($conn,$path)."' WHERE id='".mysqli_real_escape_string($conn,$id)."'";
            if ($conn->query($INSERT) === TRUE) {
                $message = "Your profile has updated successfully";
                echo "<script>
                alert('$message');
                window.location.href='profile.php';
                </script>";
            } else {
                echo "Error: " . $INSERT . "<br>" . $conn->error;
            }
            $conn->close();
        }

    } else {
        echo "All Fields are required";
        die();
    }
?>