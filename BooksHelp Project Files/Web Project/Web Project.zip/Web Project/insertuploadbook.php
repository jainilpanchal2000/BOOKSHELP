<?php
    session_start();
    $id = $_SESSION['id'];
    $name = $_POST['bname'];
    $name1 = $_POST['aname'];
    $sub = $_POST['sub'];
    $branch = $_POST['branch'];
    $price = $_POST['price'];
    $photo = $_FILES['pic']['name'];
    $filetmp = $_FILES['pic']['tmp_name'];
    $filetype = $_FILES['pic']['type'];
    $path = "book/".$photo;
    

    if(!empty($name))
    {
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "bookshelp";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

        if(mysqli_connect_error()){
            die('Connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
        } else {
            
            move_uploaded_file($filetmp,$path);

            $sql = "INSERT INTO book(sid,bookname,authorname,subject,branch,price,bookphoto) values ($id,'$name','$name1','$sub','$branch','$price','$path')";
            if ($conn->query($sql) === TRUE) {
                $message = "New book Uploaded successfully";
                echo "<script>
                alert('$message');
                window.location.href='book.php';
                </script>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $conn->close();
        }

    } else {
        echo "All Fields are required";
        die();
    }
?>