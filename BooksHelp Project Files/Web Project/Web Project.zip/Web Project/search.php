<?php
    session_start();
    $x = $_POST['srch'];
    $_SESSION['search_query']=$x;
    header('location:book.php');
?>