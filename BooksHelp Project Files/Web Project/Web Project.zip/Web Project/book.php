<?php
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>BooksHelp</title>

        <!--Home Page Animation-->
        <link href="CSS/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="CSS/font-awesome.min.css">
        <link rel="stylesheet" href="CSS/animate.css">
        <link href="CSS/prettyPhoto.css" rel="stylesheet">
        <link href="CSS/style.css" rel="stylesheet">

        <link rel="stylesheet" href="CSS/footer.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="CSS/home/slider.css">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

      <style>
        .info{
          width: 100%;
          text-align: center;
          text-align: justify;
          padding: 20px 200px;
          color: green;
          font-family : monospace;
        }

        .dropdown .dropbtn {
          border: none;
          outline: none;
          color: white;
          background-color: inherit;
        }

        .dropdown:hover .dropbtn {
          color: black;
        }

        .dropdown-content {
          display: none;
          position: absolute;
          background-color: #f9f9f9;
          min-width: 160px;
          box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
          z-index: 1;
        }

        .dropdown-content a {
          float: none;
          color: black;
          padding: 12px 16px;
          text-decoration: none;
          display: block;
          text-align: left;
        }

        .dropdown-content a:hover {
          background-color: #ddd;
        }


        .dropdown:hover .dropdown-content {
          display: block;
        }

        .dropdown-submenu {
          position: relative;
        }

        .dropdown-submenu .dropdown-menu {
          top: 0;
          left: 100%;
          margin-top: -1px;
        }

        .btn{
          background: green;
          
        }
          
          .books{
            width: 80%;
            padding: 10px;
            align-content: center;
          }
          
          .bookphoto{
              height: 250px;
              width: 250px;
              box-shadow: rgba(0,0,0,0.1);
              border: 5px solid gray;
              margin-left: 300px;
              margin-right: 50px;
              border-radius: 10px;
              padding: 0px;
              margin-bottom: 60px;
          }
          .bookbtn{
              background-color: gray;
              color: white;
              font-size: 17px;
          }
          .bookbtn:hover{
              background-color: white;
              color: green;
          }
        
          .search1{
              width: 150px;
              background-color: silver;
              border-radius: 5px;
              margin-left: 5px;
              color: black;
          }
          .searchbtn{
              background-color: darkgreen;
              color: white;
              border-radius: 8px;
          }
          .searchbtn:hover{
              background-color: lightgreen;
              color:black;
          }
          
      </style>


    </head>
<body>



    <!-- Navigation Bar -->
    <header>
            <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
              <div class="navigation">
                <div class="container">
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                    <div class="navbar-brand">
                      <a href="HOME.php"><h1><span>Books</span>Help</h1></a>
                    </div>
                  </div>
        
                  <div class="navbar-collapse collapse">
                    <div class="menu">
                      <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation"><a href="HOME.php">Home</a></li>
                        <li role="presentation"><a href="book.php" class="active">Books</a></li>
                        <li role="presentation"><a href="about.php">About Us</a></li>
                        <li role="presentation"><a href="Contact.php">Contact</a></li>
                        <?php 
                        if(isset($_SESSION['logged']) && $_SESSION['logged']==true)
                        {
                          echo '<li role="presentation"><a href="profile.php">'.$_SESSION['user'],'</a></li>';
                          echo '<li role="presentation"><a href="signout.php">Sign Out</a></li>';
                        }
                        else
                        {
                          echo '<li role="presentation"><a href="Login.php">Log In</a></li>';
                          echo '<li role="presentation"><a href="signup.php">Sign Up</a></li>';
                        }
                        ?>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </nav>
    </header>


    <div id="breadcrumb">
    <div class="container">
      <div class="breadcrumb">
        <li><a href="HOME.php">Home</a></li>
        <li>Books</li>
        <?php 
            if(isset($_SESSION['logged']) && $_SESSION['logged']==true)
            {
                echo '<li class="dropdown">
                        <button class="dropbtn">'.$_SESSION['user'],' 
                          <i class="fa fa-caret-down"></i>
                        </button>
                          <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="uploadbook.php">Upload a book</a>
                            <a href="signout.php">Log Out</a>
                          </div>
                      </li> ';
            }
            else
            {
              echo '<li>Your Account</li>';
            }
        ?>
          
            <li><form action="search.php" method="post" style="float:right;margin-right: 50px;visibility:visible;">
                <input type="text" name="srch" class="search1" placeholder="search by name">
                <input type="submit" value="search" class="searchbtn">  
          </form></li>
      </div>
    </div>
  </div>

    <div class="info" >
        <h3> Here you can upload the books that you have purchased from any store for reference and now you don't need them and you want some money for it.
             And you can brows books that you want to refer. You can contact the book holder to take the book from him/her. Similarly for your book you will be 
             contacted by someone who is interested to buy your book. You have to provide the price of book and it should be 60% of the original price at which 
             you have bought the book. <b>If you will return to the shopkeeper he will give you 40% and again he will sell to someone at 60%. This lost will be no more. :)</b>
             </h3>
        <h2>Take a look</h2>
    </div>

  
   <div class="books">
    <?php
        $host = "localhost";
        $dbUsername = "root";
        $dbPassword = "";
        $dbname = "bookshelp";

        $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
      
        if(mysqli_connect_error()){
            die('Connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
        } else {
            
            if(isset($_SESSION['search_query']))
            {
               
                $sql = "SELECT * from book where bookname='".$_SESSION['search_query']."'";
                $rnum = $conn->query($sql);
                if($rnum->num_rows > 0){
                    while($row = $rnum->fetch_assoc()){

                        if(isset($_SESSION['logged']) && $_SESSION['logged']==true)
                        {

                            echo "<div class='row m-3'>";
                            echo "<img src=".$row['bookphoto']." class='bookphoto col-sm-6'></a>";
                            echo "<div class='col-sm-6'>";
                            echo "<pre>";
                            echo "<h3> Name        : ".$row['bookname']."</h3>";
                            echo "<h3> Author Name : ".$row['authorname']."</h3>";
                            echo "<h3> Subject     : ".$row['subject']."</h3>";
                            echo "<h3> Department  : ".$row['branch']."</h3>";
                            echo "<h3> Price       : ".$row['price']."</h3>";
    //                        $sid = $row['sid'];
                            echo "<form action='showuser.php' method='POST'>";
                            echo "<input type='hidden' name='sid' value=".$row['sid'].">";
                            echo "     <input type='submit' value='See Details' class='bookbtn'>";
                            echo "</form>";
                            echo "</pre>";
                            echo "</div>";
                            echo "</div>";

                        }
                        else
                        {
                            echo "<div class='row m-3'>";
                            echo "<img src=".$row['bookphoto']." class='bookphoto col-sm-6'></a>";
                            echo "<div class='col-sm-6'>";
                            echo "<pre>";
                            echo "<h3> Name        : ".$row['bookname']."</h3>";
                            echo "<h3> Author Name : ".$row['authorname']."</h3>";
                            echo "<h3> Subject     : ".$row['subject']."</h3>";
                            echo "<h3> Department  : ".$row['branch']."</h3>";
                            echo "<h3> Price       : ".$row['price']."</h3>";
                            $sid = $row['sid'];
                            echo "<form action='dontshowuser.php' method='POST'>";
                            echo "<input type='submit' value='See Details' class='bookbtn'>";
                            echo "</form>";
                            echo "</pre>";
                            echo "</div>";
                            echo "</div>";
                        }
                    }
                }
                unset($_SESSION['search_query']);
                
            }
            else{
                $sql = "SELECT * from book";
                $rnum = $conn->query($sql);
                if($rnum->num_rows > 0){
                    while($row = $rnum->fetch_assoc()){

                        if(isset($_SESSION['logged']) && $_SESSION['logged']==true)
                        {

                            echo "<div class='row m-3'>";
                            echo "<img src=".$row['bookphoto']." class='bookphoto col-sm-6'></a>";
                            echo "<div class='col-sm-6'>";
                            echo "<pre>";
                            echo "<h3> Name        : ".$row['bookname']."</h3>";
                            echo "<h3> Author Name : ".$row['authorname']."</h3>";
                            echo "<h3> Subject     : ".$row['subject']."</h3>";
                            echo "<h3> Department  : ".$row['branch']."</h3>";
                            echo "<h3> Price       : ".$row['price']."</h3>";
    //                        $sid = $row['sid'];
                            echo "<form action='showuser.php' method='POST'>";
                            echo "<input type='hidden' name='sid' value=".$row['sid'].">";
                            echo "     <input type='submit' value='See Details' class='bookbtn'>";
                            echo "</form>";
                            echo "</pre>";
                            echo "</div>";
                            echo "</div>";

                        }
                        else
                        {
                            echo "<div class='row m-3'>";
                            echo "<img src=".$row['bookphoto']." class='bookphoto col-sm-6'></a>";
                            echo "<div class='col-sm-6'>";
                            echo "<pre>";
                            echo "<h3> Name        : ".$row['bookname']."</h3>";
                            echo "<h3> Author Name : ".$row['authorname']."</h3>";
                            echo "<h3> Subject     : ".$row['subject']."</h3>";
                            echo "<h3> Department  : ".$row['branch']."</h3>";
                            echo "<h3> Price       : ".$row['price']."</h3>";
                            $sid = $row['sid'];
                            echo "<form action='dontshowuser.php' method='POST'>";
                            echo "<input type='submit' value='See Details' class='bookbtn'>";
                            echo "</form>";
                            echo "</pre>";
                            echo "</div>";
                            echo "</div>";
                        }

                    }
                }
            }
        }
      ?>
  
  </div>





  <!-- Footer -->
  <footer class="footer-distributed">

    <div class="footer-left">      
      <div class="navbar-brand">
        <a href="HOME.php"><h1><span>BOOKS</span>HELP</h1></a>
      </div>
      <p class="footer-links" style="display: inline; margin-left: 120px">
        <a href="#">Home</a>
        --
        <a href="#">Books</a>
        --
        <a href="#">About</a>
        --
        <a href="#">Contact</a>     
      </p>
    </div>
  
      
  
    <div class="footer-center">
  
      <div>
        <i class="fa fa-map-marker"></i>
        <p><span>C-2, Anand</span> Gujarat, India</p>
      </div>
  
      <div>
        <i class="fa fa-phone"></i>
        <p>+91 81-53-047061</p>
      </div>
  
      <div>
        <i class="fa fa-envelope"></i>
        <p><a href="mailto:support@company.com">support@BooksHelp.com</a></p>
      </div>
  
    </div>
  
    <div class="footer-right">
  
      <p class="footer-company-about">
        <span>About the company</span>
        We value the art. We believe in loyalty. 
        Our motto is accuracy and perfection.
        We provide best collection over the world.
      </p>
  
      <div class="footer-icons">
        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
        <a href="#"><i class="fa fa-github"></i></a>
      </div>
    </div>

    <div class="copyright">
        &copy; BooksHelp. All Rights Reserved.
        <div class="credits" style="font-family: initial;color: grey">
          Designed by <a href="#">Kaushal</a></div>
      </div>

      <div class="pull-right">
        <a href="#home" class="scrollup"><i class="fa fa-angle-up fa-3x"></i></a>
      </div>
  </footer>
    
    
    
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="JS/jquery.min.js"></script>
      <script src="JS/jquery-migrate.min.js"></script>
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="JS/bootstrap.min.js"></script>
      <script src="JS/jquery.prettyPhoto.js"></script>
      <script src="JS/jquery.isotope.min.js"></script>
      <script src="JS/wow.min.js"></script>
      <script src="JS/functions.js"></script>

      <script src="JS/home/slider.js"></script>

      <script>
        $(document).ready(function(){
          $('.dropdown-submenu a.test').on("click", function(e){
            $(this).next('ul').toggle();
            e.stopPropagation();
            e.preventDefault();
          });
        });
      </script>

</body>
</html>