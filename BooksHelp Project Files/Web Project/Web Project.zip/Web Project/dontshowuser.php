<?php
    echo "<script>
        alert('To see the details you need to log in');
        window.location.href='book.php';
    </script>";
?>