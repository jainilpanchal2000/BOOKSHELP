<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BooksHelp/About Us</title>

  <!-- Bootstrap -->
  <link href="CSS/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="CSS/animate.css">
  <link href="CSS/prettyPhoto.css" rel="stylesheet">
  <link href="CSS/style.css" rel="stylesheet" />

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">
  
  <link rel="stylesheet" href="CSS/footer.css">

  <link href="agency.min.css" rel="stylesheet">

  <style>
    .contain{
      text-align: center;
      
    }
    .contain26{
      display: inline-block;
    }

      .team{
          /* align-items: center; */
          /* text-align: center; */
          padding: 49px 10px;
          /* align-content: center;  */
          position: relative;
          /* margin-left: 100px; */
          /* display: inline-block; */
      }
        .cont29 {
            position: relative;
            width: 50%;
            border-radius: 20px;
        }
        
        .image29 {
          display: block;
          width: 100%;
          height: auto;
        }
        
        .overlay29 {
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          background-color:aliceblue;
          overflow: hidden;
          width: 100%;
          height: 0;
          transition: .5s ease;
          border: 1.5px solid black;
        }
        
        .cont29:hover .overlay29 {
          height: 45%;
        }
        
        .text29 {
          /* color: white; */
          font-size: 20px;
          position: absolute;
          top: 50%;
          left: 50%;
          -webkit-transform: translate(-50%, -50%);
          -ms-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
          text-align: center;
        }
        .one_row{
          display: flex;
	        justify-content: center;
	        -ms-align-items: center;
	        align-items: center;
          padding: 0px 20px;
        }
        .list-unstyled li a:hover{
          color:blue;
        }
        
        .dropdown .dropbtn {
          border: none;
          outline: none;
          color: white;
          background-color: inherit;
        }

        .dropdown:hover .dropbtn {
          color: black;
        }

        .dropdown-content {
          display: none;
          position: absolute;
          background-color: #f9f9f9;
          min-width: 160px;
          box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
          z-index: 1;
        }

        .dropdown-content a {
          float: none;
          color: black;
          padding: 12px 16px;
          text-decoration: none;
          display: block;
          text-align: left;
        }

        .dropdown-content a:hover {
          background-color: #ddd;
        }


        .dropdown:hover .dropdown-content {
          display: block;
        }

        .dropdown-submenu {
          position: relative;
        }

        .dropdown-submenu .dropdown-menu {
          top: 0;
          left: 100%;
          margin-top: -1px;
        }

        .btn{
          background: green;
          
        }
      
        .rounded-circle{border-radius:50%!important}
        .img-fluid{max-width:100%;height:auto}
    </style>
</head>

<body>
  <header>
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="navigation">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
            <div class="navbar-brand">
              <a href="HOME.php"><h1><span>BOOKS</span>help</h1></a>
            </div>
          </div>

          <div class="navbar-collapse collapse">
            <div class="menu">
              <ul class="nav nav-tabs" role="tablist">
                <li role="presentation"><a href="HOME.php">Home</a></li>
                <li role="presentation"><a href="book.php">Books</a></li>
                <li role="presentation"><a href="about.php" class="active">About Us</a></li>
                <li role="presentation"><a href="Contact.php">Contact</a></li>
                <?php 
                        if(isset($_SESSION['logged']) && $_SESSION['logged']==true)
                        {
                          echo '<li role="presentation"><a href="profile.php">'.$_SESSION['user'],'</a></li>';
                          echo '<li role="presentation"><a href="signout.php">Sign Out</a></li>';
                        }
                        else
                        {
                          echo '<li role="presentation"><a href="Login.php">Log In</a></li>';
                          echo '<li role="presentation"><a href="signup.php">Sign Up</a></li>';
                        }
                ?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>
  </header>

    <div id="breadcrumb">
    <div class="container">
      <div class="breadcrumb">
        <li><a href="HOME.php">Home</a></li>
        <li>About Us</li>
        <?php 
            if(isset($_SESSION['logged']) && $_SESSION['logged']==true)
            {
                echo '<li class="dropdown">
                        <button class="dropbtn">'.$_SESSION['user'].' 
                          <i class="fa fa-caret-down"></i>
                        </button>
                          <div class="dropdown-content">
                            <a href="profile.php">Profile</a>
                            <a href="uploadbook.php">Upload a book</a>
                            <a href="signout.php">Log Out</a>
                          </div>
                      </li> ';
            }
            else
            {
              echo '<li>Your Account</li>';
            }
        ?>
      </div>
    </div>
  </div>





  <section class="page-section" id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">About</h2>
            <h3 class="section-subheading text-muted">Something about BooksHelp</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <ul class="timeline">
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/1.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading" style="color: black;">
                    <h4>July 2019</h4>
                    <h4 class="subheading">Our Humble Beginnings</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">We started it as a project. We were having the idea since our first year of engineering. But at that time we were just having the idea not the knowledge of how we can do it. </p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/4.jpg" alt="">
                </div>
                <div class="timeline-panel" style="color: black;">
                  <div class="timeline-heading">
                    <h4>August 2019</h4>
                    <h4 class="subheading">Name was given</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Our idea was to help the students with buying old books as many students can't afford new books every time and we are not having enough books in library. So we thought <b>BooksHelp</b> will be the best.</p>
                  </div>
                </div>
              </li>
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/3.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading" style="color: black;">
                    <h4>September 2019</h4>
                    <h4 class="subheading">Construction of site</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">To fulfill the idea we need a plateform. And website is a better option. So we started to build a website, through which students can get to know from whom I can get the book related to me. How much it will cost me?</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted" style="color: black;">
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/2.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>October 2019</h4>
                    <h4 class="subheading">Launching our IDEA</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Finally our website is ready to fulfill our idea. So we launched it. It will be the good plateform for students to get old books. Hope our vision behind this can be helpful to students. </p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <h4>Be Part
                    <br>Of Our
                    <br>Story!</h4>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

<h1 style="text-align: center;font-family: monospace;color: black;"><b>Our Amazing Team</b></h1>
<div class="contain one_row">
<div class="team" style="margin-left: 300px;">
  <div class="cont29">
        <img src="img/me.jpg" alt="Mr. Kaushal" class="image29">
        <div class="overlay29">
          <div class="text29">
              <ul class="list-unstyled one_row" >
                  <li><a href="#" style="padding: 3px 20px;"><i class="fa fa-facebook"></i></a></li>
                  <li><a href="#" style="padding: 3px 20px;"><i class="fa fa-twitter"></i></a></li>
                  <li><a href="#" style="padding: 3px 20px;"><i class="fa fa-linkedin"></i></a></li>
                </ul>
                <span style="color: black; padding: 7px;">Design Expert</span>
                <a href="#" style="text-decoration: none"><h4 style="margin-bottom: 0px;padding-top: 10px;"><b>Kaushal Mistry</b></h4></a>
          </div>
        </div>
</div>
</div>

<div class="team">
    <div class="cont29">
          <img src="img/sahid.jpeg" alt="Mr. Sahid" class="image29">
          <div class="overlay29">
            <div class="text29">
                <ul class="list-unstyled one_row" >
                    <li><a href="#" style="padding: 3px 20px;"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" style="padding: 3px 20px;"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" style="padding: 3px 20px;"><i class="fa fa-linkedin"></i></a></li>
                  </ul>
                  <span style="color: black; padding: 7px;">Design Expert</span>
                  <h4 style="margin-bottom: 0px;padding-top: 10px;"><b>Sahid Vhora</b></h4>
            </div>
          </div>
  </div>
  </div>

  </div>




  <!-- Footer -->
  <footer class="footer-distributed">

    <div class="footer-left">      
      <div class="navbar-brand">
        <a href="HOME.php"><h1><span>BOOKS</span>HELP</h1></a>
      </div>
      <p class="footer-links" style="display: inline; margin-left: 120px">
        <a href="#">Home</a>
        --
        <a href="#">Books</a>
        --
        <a href="#">About</a>
        --
        <a href="#">Contact</a>     
      </p>
    </div>
  
      
  
    <div class="footer-center">
  
      <div>
        <i class="fa fa-map-marker"></i>
        <p><span>C-2, Anand</span> Gujarat, India</p>
      </div>
  
      <div>
        <i class="fa fa-phone"></i>
        <p>+91 81-53-047061</p>
      </div>
  
      <div>
        <i class="fa fa-envelope"></i>
        <p><a href="mailto:support@company.com">support@BooksHelp.com</a></p>
      </div>
  
    </div>
  
    <div class="footer-right">
  
      <p class="footer-company-about">
        <span>About the company</span>
        We value the art. We believe in loyalty. 
        Our motto is accuracy and perfection.
        We provide best collection over the world.
      </p>
  
      <div class="footer-icons">
        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-linkedin"></i></a>
        <a href="#"><i class="fa fa-github"></i></a>
      </div>
    </div>

    <div class="copyright">
        &copy; BooksHelp. All Rights Reserved.
        <div class="credits" style="font-family: initial;color: grey">
          Designed by <a href="#">Kaushal</a></div>
      </div>
  </footer>

</body>
</html>
