<?php
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $birthDate = $_POST['bdate'];
    $Gender = $_POST['gender'];
    $email = $_POST['email'];
    $MoNo = $_POST['mono'];
    $Password = $_POST['psw'];
    
?>